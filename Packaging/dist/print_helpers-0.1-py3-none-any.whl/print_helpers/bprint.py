def upper_print(message):
    print(message.upper())

